
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes');
var http = require('http');
var path = require('path');

//load customers route
var customers = require('./routes/customers'); 
var app = express();
const request = require('request');
const async= require('async');
var connection  = require('express-myconnection'); 
var mysql = require('mysql');


// all environments
app.set('port', process.env.PORT || 4300);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
//app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());

app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

/*------------------------------------------
    connection peer, register as middleware
    type koneksi : single,pool and request 
-------------------------------------------*/

app.use(
    
    connection(mysql,{
        
        host: 'db4free.net',
        user: 'jonathantilla',
        password : 'jona7han7614',
        port : 3306, //port mysql
        database:'turisticos',

    },'pool') //or single

);

//para cosumir los daros
app.get('/datos',(req,res) => {
	async.times(1,(i, callback) => {
		var options ={
			url:'https://www.datos.gov.co/resource/2r8y-vqxz.json',
		}
		request(options.url,(error,response,body) =>{
			var result= JSON.parse(body);
			callback(null, result);
			console.log(data);
		});
	},(err, error)=>{
		res.json(error);	
	})
})
//fin de consumo de datos
//_\|--|/__/|*-|\__/|**|\__--__--__--__
//Discriminante de datos
app.get('/consulta', (req,res) =>{
	async.times(1,(i,callback)=>{
		var options ={
			url:'https://www.datos.gov.co/resource/2r8y-vqxz.json',
		}
		request(options.url, (error,response,body) =>{
			var result = JSON.parse(body);
			var dato= result;
			var muni='';
			var red1='';
			var correo='';

			dato.forEach(function(posicion){
			 muni = muni + posicion.municipio + "\n";
				
			 red1 = red1 + posicion.red+"\n";	
			 correo =correo+ posicion.email+"\n";	
});
			console.log(muni+"\t"+red1 + "\t" +correo);
			
			callback(null, dato);
		});
	}, (err, error) => {	
		res.json(error);
	});
})
//Fin de discriminante de datos

app.get('/', routes.index);
app.get('/customers', customers.list);
app.get('/customers/add', customers.add);
app.post('/customers/add', customers.save);
app.get('/customers/delete/:id', customers.delete_customer);
app.get('/customers/edit/:id', customers.edit);
app.post('/customers/edit/:id',customers.save_edit);


app.use(app.router);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
